create function get_employee_by_dept("char") returns "char"
    language plpgsql
as
$$DECLARE 
BEGIN

END;$$;

alter function get_employee_by_dept("char") owner to postgres;

