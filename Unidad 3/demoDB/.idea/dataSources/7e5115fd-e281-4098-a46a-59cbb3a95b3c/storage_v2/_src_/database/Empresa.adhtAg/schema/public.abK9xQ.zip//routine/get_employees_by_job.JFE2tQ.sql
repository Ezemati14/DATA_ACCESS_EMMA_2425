create function get_employees_by_job(job_name character varying)
    returns TABLE(empno integer, ename character varying, job character varying, deptno integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT e.empno, e.ename, e.job, e.deptno
    FROM employee e
    WHERE e.job = job_name;
END;
$$;

alter function get_employees_by_job(varchar) owner to postgres;

