create function get_employee_by_dept(dept_number integer)
    returns TABLE(empno integer, ename character varying, job character varying, deptno integer)
    language plpgsql
as
$$
DECLARE 
BEGIN
	RETURN QUERY
	SELECT e.empno, e.ename, e.job, e.deptno
	FROM employee e
	WHERE e.deptno = dept_number;
END;
$$;

alter function get_employee_by_dept(integer) owner to postgres;

