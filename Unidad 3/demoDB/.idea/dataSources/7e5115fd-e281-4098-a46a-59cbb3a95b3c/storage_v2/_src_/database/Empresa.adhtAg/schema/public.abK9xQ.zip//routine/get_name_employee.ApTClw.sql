create function get_name_employee("char") returns "char"
    language plpgsql
as
$$DECLARE
cantidad INTEGER;
BEGIN
	
END;$$;

alter function get_name_employee("char") owner to postgres;

