create function get_name_employee(prefix character varying)
    returns TABLE(empno integer, ename character varying, job character varying, deptno integer)
    language plpgsql
as
$$
DECLARE
BEGIN
	RETURN QUERY
	SELECT e.empno, e.ename, e.job, e.deptno
	FROM employee e 
	WHERE e.ename ILIKE prefix || '%';
END;
$$;

alter function get_name_employee(varchar) owner to postgres;

