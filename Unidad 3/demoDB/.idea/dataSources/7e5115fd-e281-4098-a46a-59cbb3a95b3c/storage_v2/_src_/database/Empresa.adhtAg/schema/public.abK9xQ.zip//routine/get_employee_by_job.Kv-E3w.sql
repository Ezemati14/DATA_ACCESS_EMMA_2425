create function get_employee_by_job(integer) returns integer
    language plpgsql
as
$$DECLARE 
cantidad INTEGER;
BEGIN

END;$$;

alter function get_employee_by_job(integer) owner to postgres;

